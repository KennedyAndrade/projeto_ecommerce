<?php

define("ENVIRONMENT", "development");

?>